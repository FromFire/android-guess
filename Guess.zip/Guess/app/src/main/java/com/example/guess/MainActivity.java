package com.example.guess;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int answer;
    EditText input;
    Button check_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        answer = (new Random()).nextInt(9999);
        //answer = 1000;
        check_button = findViewById(R.id.check_button);
        input = findViewById(R.id.inputNumber);
        input.addTextChangedListener(input_watcher);
    }

    public void check_answer(View V) {

        input = findViewById(R.id.inputNumber);
        int guess = Integer.valueOf(input.getText().toString());
        if(answer == guess) {
            setContentView(R.layout.right_answer);
            TextView ans = findViewById(R.id.answer);

            String output = String.valueOf(answer);
            while(output.length()<4) output = "0" + output;
            ans.setText(output.toCharArray(), 0, 4);
            return;
        }
        setContentView(R.layout.wrong_answer);
        updateWrongGuess(guess);
    }

    private void updateWrongGuess(int guess) {
        String output = String.valueOf(guess);
        while(output.length()<4) output = "0" + output;
        input = findViewById(R.id.inputNumber);
        input.addTextChangedListener(input_watcher);
        input.setText(output.toCharArray(), 0, 4);

        ImageView bigger = findViewById(R.id.bigger);
        ImageView smaller = findViewById(R.id.smaller);
        if(answer > guess) {
            bigger.setVisibility(View.INVISIBLE);
            smaller.setVisibility(View.VISIBLE);
        }
        else {
            bigger.setVisibility(View.VISIBLE);
            smaller.setVisibility(View.INVISIBLE);
        }
    }


    TextWatcher input_watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}

        @Override
        public void afterTextChanged(Editable edit) {
            //edit  输入结束呈现在输入框中的信息
            if(edit.toString().length() == 4)
                check_button.setEnabled(true);
            else
                check_button.setEnabled(false);
        }
    };
    }




